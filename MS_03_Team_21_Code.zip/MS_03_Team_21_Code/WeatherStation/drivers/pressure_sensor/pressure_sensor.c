#include <stdio.h>
#include "pico/stdlib.h"
#include "pressure_sensor.h"

void initBMP180()
{
    i2c_init_bmp180();
}

float readPressureBMP()
{
    data_from_bmp180 current_data = get_bmp180_sensor_data(3);
    return (current_data.atmospheric_pressure_in_Pa / 100);    
}

float readTemperatureBMP()
{
    data_from_bmp180 current_data = get_bmp180_sensor_data(3);
    return (current_data.air_temperature_in_celisus);
}
