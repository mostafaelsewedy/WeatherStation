#ifndef BMP180_H
#define BMP180_H

#include "bmp180.h"

void initBMP180();
float readPressureBMP();
float readTemperatureBMP();

#endif
