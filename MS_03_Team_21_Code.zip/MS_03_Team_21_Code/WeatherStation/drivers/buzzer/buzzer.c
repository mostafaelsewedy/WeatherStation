#include "pico/stdlib.h"
#include "buzzer.h"

void initBuzzer()
{
    gpio_init(BUZZER_PIN);
    gpio_set_dir(BUZZER_PIN, GPIO_OUT);
}

void turnBuzzerOn()
{
    gpio_put(BUZZER_PIN, 1);
}

void turnBuzzerOff()
{
    gpio_put(BUZZER_PIN, 0);
}
