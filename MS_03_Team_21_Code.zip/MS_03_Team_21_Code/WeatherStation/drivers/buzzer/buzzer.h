#ifndef BUZZER_H
#define BUZZER_H

#define BUZZER_PIN 16

void initBuzzer();
void turnBuzzerOn();
void turnBuzzerOff();

#endif
