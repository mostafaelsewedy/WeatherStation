#ifndef DHT11_H
#define DHT11_H
#include "dht.h"

#define DHT_PIN 17
#define DHT_TYPE DHT11

extern dht_t mydht;

void initDHT11();
float readTemperatureDHT();
float readHumidityDHT();

#endif