#include <stdio.h>
#include "pico/stdlib.h"
#include "temperature_humidity.h"

void initDHT11() {
    dht_init(&mydht, DHT_TYPE, pio0, DHT_PIN, true);
    dht_start_measurement(&mydht);
}

float readTemperatureDHT() {
    float temperature;
    float humidity;
    dht_result_t result = dht_finish_measurement_blocking(&mydht, &humidity, &temperature);
    if (result == DHT_RESULT_OK) {
        return temperature;
    } else if (result == DHT_RESULT_TIMEOUT) {
        printf("DHT sensor not responding. Please check your wiring.\n");
        return -1.0;
    } else {
        assert(result == DHT_RESULT_BAD_CHECKSUM);
        printf("Bad checksum.\n");
        return -1.0;
    }
}

float readHumidityDHT() {
    float temperature;
    float humidity;
    dht_result_t result = dht_finish_measurement_blocking(&mydht, &humidity, &temperature);
    if (result == DHT_RESULT_OK) {
        return humidity;
    } else if (result == DHT_RESULT_TIMEOUT) {
        printf("DHT sensor not responding. Please check your wiring.\n");
        return -1.0;
    } else {
        assert(result == DHT_RESULT_BAD_CHECKSUM);
        printf("Bad checksum.\n");
        return -1.0;
    }
}
