#ifndef LED_H
#define LED_H

#define GREEN_LED_PIN 25
#define RED_LED_PIN 15

void initLEDs();
void turnGreenOn();
void turnRedOn();
void turnOffLEDs();
void fadeLED(uint pin);

#endif
