#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "led.h"

const int fadeDelay = 20;
const int fadeSpeed = 5; 

void initLEDs()
{
    gpio_set_function(GREEN_LED_PIN, GPIO_FUNC_PWM);
    gpio_set_function(RED_LED_PIN, GPIO_FUNC_PWM);

    uint slice_num_green = pwm_gpio_to_slice_num(GREEN_LED_PIN);
    uint slice_num_red = pwm_gpio_to_slice_num(RED_LED_PIN);

    pwm_set_wrap(slice_num_green, 255);
    pwm_set_wrap(slice_num_red, 255);

    pwm_set_enabled(slice_num_green, true);
    pwm_set_enabled(slice_num_red, true);
}

void setPWMLevel(uint pin, int level)
{
    uint slice_num = pwm_gpio_to_slice_num(pin);
    uint channel = pwm_gpio_to_channel(pin);

    pwm_set_chan_level(slice_num, channel, level);
}

void fadeLED(uint pin)
{
    for (int brightness = 0; brightness <= 255; brightness++)
    {
        setPWMLevel(pin, brightness);
        sleep_ms(fadeDelay);
    }

    for (int brightness = 255; brightness >= 0; brightness--)
    {
        setPWMLevel(pin, brightness);
        sleep_ms(fadeDelay);
    }
}

void turnGreenOn()
{
    fadeLED(GREEN_LED_PIN);
    setPWMLevel(RED_LED_PIN, 0);
}

void turnRedOn()
{
    setPWMLevel(GREEN_LED_PIN, 0);
    fadeLED(RED_LED_PIN);
}

void turnOffLEDs()
{
    setPWMLevel(GREEN_LED_PIN, 0);
    setPWMLevel(RED_LED_PIN, 0);
}