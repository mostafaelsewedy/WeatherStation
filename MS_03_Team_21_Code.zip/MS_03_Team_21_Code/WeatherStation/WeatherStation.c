#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "drivers/led/led.h"
#include "drivers/buzzer/buzzer.h"
#include "drivers/temperature_humidity_sensor/temperature_humidity.h"
#include "drivers/pressure_sensor/pressure_sensor.h"

#define TEMP_MIN 20.0
#define TEMP_MAX 30.0
#define HUMIDITY_THRESHOLD 50.0
#define PRESSURE_MIN 980.0
#define PRESSURE_MAX 1000.0

#define UART_ID uart0
#define BAUD_RATE 9600
#define TX_PIN 0
#define RX_PIN 1

dht_t mydht;

float PRESSURE_AVG = 0;
float HUMIDITY_AVG = 0;
float TEMP_AVG = 0;
int count = 1;

void init_uart()
{
    uart_init(UART_ID, BAUD_RATE);
    gpio_set_function(TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(RX_PIN, GPIO_FUNC_UART);
}

int main()
{

    stdio_init_all();
    initLEDs();
    initBuzzer();
    initDHT11();
    initBMP180();
    init_uart();

    sleep_ms(5000);

    while (true)
    {
        float temperatureDHT = readTemperatureDHT();
        float humidity = readHumidityDHT();
        float pressure = readPressureBMP();
        float temperatureBMP = readTemperatureBMP();

        float temperatureAverage = (temperatureBMP + temperatureDHT) / 2;

        if (temperatureAverage >= TEMP_MIN && temperatureAverage <= TEMP_MAX)
        {
            turnGreenOn();
        }
        else
        {
            turnRedOn();
        }

        if ((pressure >= PRESSURE_MIN && pressure <= PRESSURE_MAX) && humidity <= HUMIDITY_THRESHOLD)
        {
            turnBuzzerOff();
        }
        else
        {
            turnBuzzerOn();
        }

        printf("Temperature DHT: %f C\n", temperatureDHT);
        printf("Humidity: %f %\n", humidity);
        printf("Pressure: %f hPa\n", pressure);
        printf("Temperature BMP: %f C\n", temperatureBMP);
        printf("Temperature Average: %f C\n", temperatureAverage);

        PRESSURE_AVG += pressure;
        TEMP_AVG += temperatureAverage;
        HUMIDITY_AVG += humidity;

        if (count == 3)
        {
            char data_buffer[100];
            snprintf(data_buffer, sizeof(data_buffer), "%.2f,%.2f,%.2f\n", TEMP_AVG/3, HUMIDITY_AVG/3, PRESSURE_AVG/3);
            uart_puts(UART_ID, data_buffer);
            PRESSURE_AVG = 0;
            TEMP_AVG = 0;
            HUMIDITY_AVG = 0;
            count = 0;
        }
        count++;

        sleep_ms(5000);
    }
}