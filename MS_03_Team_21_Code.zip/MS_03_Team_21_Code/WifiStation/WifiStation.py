import network
import time
import urequests
import machine

# Wi-Fi credentials
SSID = "Ashraf"
PASSWORD = "ce15c2a7"

SSID2 = "Mostafa’s iPhone (2)"
PASSWORD2 = "123456788"

# ThingSpeak API credentials
THINGSPEAK_API_KEY = "PXVWOR8F68QB5DZ2"
THINGSPEAK_UPDATE_URL = "https://api.thingspeak.com/update"

UART_ID = 0
TX_PIN = 0
RX_PIN = 1
BAUD_RATE = 9600
uart = machine.UART(UART_ID, baudrate=BAUD_RATE, tx=machine.Pin(TX_PIN), rx=machine.Pin(RX_PIN))

# Connect to Wi-Fi
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID2, PASSWORD2)

    while not wlan.isconnected():
        time.sleep(1)

    print("Connected to WiFi")
    print("Network configuration:", wlan.ifconfig())

# Send a single field to ThingSpeak
def send_field_to_thingspeak(field_number, value):
    try:
        query_url = f"{THINGSPEAK_UPDATE_URL}?api_key={THINGSPEAK_API_KEY}&field{field_number}={value}"
        response = urequests.get(query_url)
        print(f"Field {field_number} sent with value {value}. Response: {response.text}")
        response.close()
    except Exception as e:
        print(f"Failed to send field {field_number} to ThingSpeak:", e)

# Main function
def main():
    connect_wifi()

    while True:
        if uart.any():  # Check if data is available from Arduino
            raw_data = uart.readline()
            if raw_data:  # Ensure raw_data is not None
                try:
                    # Decode the raw bytes into a string
                    if isinstance(raw_data, bytes):  # Check if raw_data is bytes
                        raw_data = raw_data.decode("utf-8")  # Decode to string

                    data = raw_data.strip()  # Remove any extra whitespace or newline characters
                    print(f"Data: {data}, Type: {type(data)}")

                    parts = data.split(",")
                    if len(parts) != 3:
                        raise ValueError("Data does not have exactly 3 values.")

                    # Convert the parts to floats
                    temp, humidity, pressure = map(float, parts)
                    print(f"Temperature: {temp}, Humidity: {humidity}, Pressure: {pressure}")

                    # Send each field to ThingSpeak with a 15-second delay
                    send_field_to_thingspeak(1, temp)
                    time.sleep(15)
                    send_field_to_thingspeak(2, humidity)
                    time.sleep(15)
                    send_field_to_thingspeak(3, pressure)
                    time.sleep(15)

                except ValueError:
                    print("Invalid data format received.")


        else:
            time.sleep(1)  # Wait for new data

# Run the program
main()